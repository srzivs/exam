--사원명(ENAME)이 SCOTT 인 사람의 정보를 모두 화면에 표시하세요. 
--사원테이블: EMPLOYEE
SELECT * FROM EMPLOYEE WHERE ENAME='SCOTT';